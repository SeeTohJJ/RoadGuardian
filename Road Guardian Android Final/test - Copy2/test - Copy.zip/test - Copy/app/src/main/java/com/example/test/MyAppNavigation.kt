package com.example.test

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.test.pages.CameraPage
import com.example.test.pages.HazardReportingPage
import com.example.test.pages.HomePage
import com.example.test.pages.HomeScreenPage
//import com.example.test.pages.HomeScreenPage
import com.example.test.pages.LoginPage
import com.example.test.pages.MainScreen
import com.example.test.pages.NavigationMapPage
import com.example.test.pages.ProfilePage
import com.example.test.pages.RegisterPage
import com.example.test.pages.ReportPage
//import com.example.test.pages.ReportPage
import com.example.test.pages.ResetPwEmailPage
import com.example.test.pages.ResetPwPage
import com.example.test.pages.TempPasswordLoginPage
import com.example.test.ui.theme.AuthViewModel

@Composable
fun MyAppNavigation(modifier: Modifier = Modifier, authViewModel: AuthViewModel) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "login", builder = {
        composable("login"){
            LoginPage(modifier, navController, authViewModel)
        }
        composable("register"){
            RegisterPage(modifier, navController, authViewModel)
        }
        composable("home"){
            HomePage(modifier, navController,authViewModel)
        }
        composable("resetPwPage"){
            ResetPwPage(modifier, navController,authViewModel)
        }
        composable("resetPwEmailPage"){
            ResetPwEmailPage(modifier, navController,authViewModel)
        }
        composable("tempPasswordLoginPage"){
            TempPasswordLoginPage(modifier, navController,authViewModel)
        }
        composable("cameraPage"){ // Reference CameraPage Composable
            CameraPage(modifier, navController)
        }
        composable("hazardReportingPage/{photoPath}") { backStackEntry ->
            val photoPath = backStackEntry.arguments?.getString("photoPath")
            HazardReportingPage(modifier, photoPath = photoPath, navController = navController)
        }
        composable("mainScreen"){
            MainScreen(modifier, navController, authViewModel)
        }
        composable("reportPage/{photoPath}") {
                backStackEntry ->
            val photoPath = backStackEntry.arguments?.getString("photoPath")
            ReportPage(modifier, photoPath = photoPath, navController = navController)
        }
        composable("homeScreenPage"){
            HomeScreenPage(modifier, navController, authViewModel)
        }
        composable("profilePage"){
            ProfilePage(modifier, navController, authViewModel)
        }
        composable("navigationMapPage"){
            NavigationMapPage(modifier, navController)
        }
    })

}