package com.example.test

data class UserDTO(
    val email: String,
    val password: String,
    val securityQuestion: String? = null, // Optional for security questions
    val securityAnswer: String? = null    // Optional for answers
)

