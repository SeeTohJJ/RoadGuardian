package com.example.test

import android.os.AsyncTask
import android.util.Log
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class BackendCall : AsyncTask<Void, Void, String>() {

    override fun doInBackground(vararg params: Void?): String? {
        var result: String? = null
        val urlString = "http://10.0.2.2:8080/api/motorists" // Replace with your API endpoint
        val url = URL(urlString)

        val urlConnection = url.openConnection() as HttpURLConnection
        try {
            // Set request method
            urlConnection.requestMethod = "GET"
            // Read the response
            val reader = BufferedReader(InputStreamReader(urlConnection.inputStream))
            val response = StringBuilder()
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                response.append(line)
            }
            result = response.toString()
        } catch (e: Exception) {
            Log.e("ApiCall", "Error: ${e.message}")
        } finally {
            urlConnection.disconnect()
        }
        return result
    }

    override fun onPostExecute(result: String?) {
        super.onPostExecute(result)
        Log.d("ApiCall", "Response: $result")
    }
}
