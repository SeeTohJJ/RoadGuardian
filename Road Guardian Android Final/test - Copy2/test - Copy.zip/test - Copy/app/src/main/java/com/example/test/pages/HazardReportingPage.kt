package com.example.test.pages

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.test.LocationTextField
import java.io.File


@Composable
fun HazardReportingPage(modifier: Modifier = Modifier, navController: NavController, photoPath: String?) {

    var typeInput by remember { mutableStateOf("") }
    var locationInput by remember { mutableStateOf("") }
    var descriptionInput by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp), // Add padding to the whole layout
        verticalArrangement = Arrangement.Top, // Align everything at the top
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Hazard Reporting Page", fontSize = 30.sp)
        Spacer(modifier = Modifier.height(16.dp))

        // Box to preview image
        Box(
            modifier = Modifier
                .wrapContentHeight() // Only take up the required height
        ) {
            if (photoPath != null) {
                // Load and display the image using Coil's AsyncImage
                AsyncImage(
                    model = File(photoPath),
                    contentDescription = "Captured Image",
                    modifier = Modifier
                        .size(300.dp)  // Adjust the size to make it smaller
                        .clip(RoundedCornerShape(16.dp))  // Optional: Round the corners
                )
            } else {
                Text("No Image Available")
            }
        }

        Spacer(modifier = Modifier.height(16.dp)) // Adjusted the spacing

        OutlinedTextField(
            value = typeInput,
            onValueChange = { typeInput = it },
            label = { Text("Type of Hazard") }
        )

        Spacer(modifier = Modifier.height(16.dp))
        //LocationTextField()

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = descriptionInput,
            onValueChange = { descriptionInput = it },
            label = { Text("Brief Description of Hazard") }
        )

        Spacer(modifier = Modifier.height(16.dp))

        val context = LocalContext.current
        Button(onClick = {
            navController.navigate("home")
            navController.navigate("mainScreen")

            Toast.makeText(context, "Report Submitted Successfully", Toast.LENGTH_SHORT).show()
        }) {
            Text(text = "Submit")

        }
    }
}
