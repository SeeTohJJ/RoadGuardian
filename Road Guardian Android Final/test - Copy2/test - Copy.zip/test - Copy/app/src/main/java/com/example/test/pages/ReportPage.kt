package com.example.test.pages

import android.annotation.SuppressLint
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.test.HazardTypeDropdown
import com.example.test.LocationTextField
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.io.File
import java.util.*

@SuppressLint("MissingPermission")
@Composable
fun ReportPage(modifier: Modifier = Modifier, navController: NavController, photoPath: String?) {
    val context = LocalContext.current
    val firestore = FirebaseFirestore.getInstance()
    val storage = FirebaseStorage.getInstance()
    val auth = FirebaseAuth.getInstance()
    val userId = auth.currentUser?.uid ?: return // Return if user is not authenticated
    var locationInput by remember { mutableStateOf("") }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }

    var typeInput by remember { mutableStateOf("") }
    var descriptionInput by remember { mutableStateOf("") }


    // Image picker launcher
    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent(),
        onResult = { uri: Uri? ->
            selectedImageUri = uri
        }
    )

    // Fetch current location for location suggestion
    val fusedLocationClient = remember { LocationServices.getFusedLocationProviderClient(context) }
    LaunchedEffect(Unit) {
        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                val latitude = location.latitude
                val longitude = location.longitude
                locationInput = "Lat: $latitude, Lon: $longitude" // Default suggestion
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Submit Report", fontSize = 24.sp)

        Spacer(modifier = Modifier.height(16.dp))
        Box(
            modifier = Modifier
                .wrapContentHeight() // Only take up the required height
        ) {
            if (photoPath != null) {
                // Load and display the image using Coil's AsyncImage
                AsyncImage(
                    model = File(photoPath),
                    contentDescription = "Captured Image",
                    modifier = Modifier
                        .size(300.dp)  // Adjust the size to make it smaller
                        .clip(RoundedCornerShape(16.dp))  // Optional: Round the corners
                )
            } else {
                Text("No Image Available")
            }
        }

        // Button to select an image
        Button(onClick = { launcher.launch("image/*") }) {
            Text("Upload Photo")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Type of hazard textfield
        HazardTypeDropdown(onTypeSelected = { type ->
            typeInput = type})

        Spacer(modifier = Modifier.height(16.dp))
        // Location Input Field
        /*TextField(
            value = locationInput,
            onValueChange = { locationInput = it },
            label = { Text("Location") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))
        */

        LocationTextField(onLocationSelected = { type ->
            locationInput = type})

        // Description Textfield
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            value = descriptionInput,
            onValueChange = { descriptionInput = it },
            label = { Text("Brief Description of Hazard") },
            modifier = Modifier.fillMaxWidth()
        )

        // Submit button
        Button(
            onClick = {
                val storageRef = storage.reference.child("images/${userId}/${System.currentTimeMillis()}")

                if (photoPath != null) {
                    // Upload from photoPath (camera capture)
                    val fileUri = Uri.fromFile(File(photoPath))
                    storageRef.putFile(fileUri)
                        .addOnSuccessListener {
                            storageRef.downloadUrl.addOnSuccessListener { uri ->
                                submitReportToFirestore(userId, locationInput, uri.toString(), firestore, typeInput, descriptionInput)
                                Toast.makeText(context, "Report submitted", Toast.LENGTH_SHORT).show()
                                navController.navigate("home")
                                navController.navigate("mainScreen")
                            }
                        }
                        .addOnFailureListener {
                            Toast.makeText(context, "Image upload failed: ${it.message}", Toast.LENGTH_SHORT).show()
                        }
                } else if (selectedImageUri != null) {
                    // Upload from selectedImageUri (image picker)
                    storageRef.putFile(selectedImageUri!!)
                        .addOnSuccessListener {
                            storageRef.downloadUrl.addOnSuccessListener { uri ->
                                submitReportToFirestore(userId, locationInput, uri.toString(), firestore, typeInput, descriptionInput)
                                Toast.makeText(context, "Report submitted", Toast.LENGTH_SHORT).show()
                            }
                        }
                        .addOnFailureListener {
                            Toast.makeText(context, "Image upload failed: ${it.message}", Toast.LENGTH_SHORT).show()
                        }
                } else {
                    // No image selected or captured
                    submitReportToFirestore(userId, locationInput, null, firestore, typeInput, descriptionInput)
                    Toast.makeText(context, "Report submitted without image", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text("Submit")
        }
    }
}

fun submitReportToFirestore(userId: String, location: String, imageUrl: String?, firestore: FirebaseFirestore, typeInput: String?, descriptionInput: String?) {
    val reportData = hashMapOf(
        "Location" to location,
        "Photo" to imageUrl,
        "Timestamp" to System.currentTimeMillis(),
        "Hazard Type" to typeInput,
        "Description" to descriptionInput
    )

    firestore.collection("Users").document(userId).collection("Report")
        .add(reportData)
        .addOnSuccessListener {
            // Report successfully submitted
            println("Firebase Report Success")
        }
        .addOnFailureListener { e ->
            // Failed to submit report
            println("Firebase Report Failure")
        }
}
