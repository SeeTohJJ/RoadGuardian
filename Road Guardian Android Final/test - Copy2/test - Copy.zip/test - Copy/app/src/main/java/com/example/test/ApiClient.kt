import android.util.Log
import com.example.test.UserDTO
import okhttp3.*
import java.io.IOException
import com.google.gson.Gson
import okhttp3.MediaType.Companion.toMediaTypeOrNull

class ApiHelper {

    private val client = OkHttpClient()
    private val gson = Gson()
    private val BASE_URL = "http://10.0.2.2:8080/api/motorists"

    // Function to log in the user
    fun login(user: UserDTO, callback: (Boolean, String?) -> Unit) {
        val json = gson.toJson(user)
        val requestBody = RequestBody.create("application/json".toMediaTypeOrNull(), json)

        val request = Request.Builder()
            .url("$BASE_URL/login")
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("ApiHelper", "Login failed: ${e.message}")
                callback(false, "Network error: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    callback(true, "Login successful")
                } else {
                    callback(false, "Login failed: ${response.message}")
                }
            }
        })
    }

    // Function to register a new user
    fun register(user: UserDTO, callback: (Boolean, String?) -> Unit) {
        val json = gson.toJson(user)
        val requestBody = RequestBody.create("application/json".toMediaTypeOrNull(), json)

        val request = Request.Builder()
            .url("$BASE_URL/register")
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("ApiHelper", "Registration failed: ${e.message}")
                callback(false, "Network error: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    callback(true, "Registration successful")
                } else {
                    callback(false, "Registration failed: ${response.message}")
                }
            }
        })
    }

    // Function to reset password
    fun resetPassword(user: UserDTO, callback: (Boolean, String?) -> Unit) {
        val json = gson.toJson(user)
        val requestBody = RequestBody.create("application/json".toMediaTypeOrNull(), json)

        val request = Request.Builder()
            .url("$BASE_URL/forgot/reset")
            .put(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("ApiHelper", "Password reset failed: ${e.message}")
                callback(false, "Network error: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    callback(true, "Password reset successful")
                } else {
                    callback(false, "Password reset failed: ${response.message}")
                }
            }
        })
    }
}
