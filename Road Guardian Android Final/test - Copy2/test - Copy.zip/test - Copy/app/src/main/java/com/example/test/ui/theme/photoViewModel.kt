package com.example.test.ui.theme

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class photoViewModel : ViewModel() {
    private val _photoPath = MutableLiveData<String?>()
    val photoPath: LiveData<String?> = _photoPath

    fun setPhotoPath(path: String?) {
        _photoPath.value = path
    }
}
