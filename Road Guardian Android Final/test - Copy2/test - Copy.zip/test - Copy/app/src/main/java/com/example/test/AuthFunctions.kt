package com.example.test

import android.util.Log
import okhttp3.*
import com.google.gson.Gson
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

class AuthFunctions {
    private val client = OkHttpClient()
    private val gson = Gson()

    // Function for login
    fun login(user: UserDTO, callback: (Boolean, String?) -> Unit) {
        val requestBody = gson.toJson(user)
            .toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())

        val request = Request.Builder()
            .url("http://10.0.2.2:8080/api/motorists/login") // Replace with your API endpoint
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    callback(true, null) // Login successful
                } else {
                    callback(false, "Login failed: ${response.message}")
                }
            }

            override fun onFailure(call: Call, e: IOException) {
                Log.e("AuthFunctions", "Error: ${e.message}")
                callback(false, e.message)
            }
        })
    }

    // Function for registration
    fun register(user: UserDTO, callback: (Boolean, String?) -> Unit) {
        val requestBody = gson.toJson(user)
            .toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())

        val request = Request.Builder()
            .url("http://10.0.2.2:8080/api/motorists/register") // Replace with your API endpoint
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    callback(true, null) // Registration successful
                } else {
                    callback(false, "Registration failed: ${response.message}")
                }
            }

            override fun onFailure(call: Call, e: IOException) {
                Log.e("AuthFunctions", "Error: ${e.message}")
                callback(false, e.message)
            }
        })
    }

    // Function for resetting password
    fun resetPassword(newPassword: String, callback: (Boolean, String?) -> Unit) {
        val requestBody =
            gson.toJson(mapOf("password" to newPassword)) // Assuming backend expects a JSON payload
                .toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())

        val request = Request.Builder()
            .url("http://10.0.2.2:8080/api/motorists/reset-password") // Replace with your API endpoint
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    callback(true, null) // Password reset successful
                } else {
                    callback(false, "Password reset failed: ${response.message}")
                }
            }

            override fun onFailure(call: Call, e: IOException) {
                Log.e("AuthFunctions", "Error: ${e.message}")
                callback(false, e.message)
            }
        })
    }

    // Function for forgot password
    fun forgotPassword(email: String, callback: (Boolean, String?) -> Unit) {
        val requestBody =
            gson.toJson(mapOf("email" to email)) // Assuming backend expects a JSON payload
                .toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())

        val request = Request.Builder()
            .url("http://10.0.2.2:8080/api/motorists/forgot-password") // Replace with your API endpoint
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    callback(true, null) // Forgot password email sent successfully
                } else {
                    callback(false, "Failed to send reset email: ${response.message}")
                }
            }

            override fun onFailure(call: Call, e: IOException) {
                Log.e("AuthFunctions", "Error: ${e.message}")
                callback(false, e.message)
            }
        })
    }

    fun getCurrentUser(callback: (UserDTO?) -> Unit) {
        val request = Request.Builder()
            .url("http://10.0.2.2:8080/api/motorists/current") // Replace with your API endpoint to get current user
            .get()
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!response.isSuccessful) {
                        Log.e("ApiCall", "Unexpected code $response")
                        callback(null)
                    } else {
                        val responseData = response.body?.string()
                        val user = gson.fromJson(responseData, UserDTO::class.java) // Deserialize JSON to UserDTO
                        callback(user) // Return user to the callback
                    }
                }
            }

            override fun onFailure(call: Call, e: IOException) {
                Log.e("ApiCall", "Error: ${e.message}")
                callback(null)
            }
        })
    }
}
